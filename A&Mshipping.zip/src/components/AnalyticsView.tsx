import React from 'react';
import { Shipment } from '../types';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  PieChart, 
  Pie, 
  Cell, 
  Legend 
} from 'recharts';
import { BarChart3, TrendingUp, CheckCircle, Truck, PackageX, DollarSign } from 'lucide-react';

interface AnalyticsViewProps {
  shipments: Shipment[];
}

export const AnalyticsView: React.FC<AnalyticsViewProps> = ({ shipments }) => {
  // Aggregate status distribution
  const statusCounts = shipments.reduce((acc: Record<string, number>, s) => {
    acc[s.status] = (acc[s.status] || 0) + 1;
    return acc;
  }, {});

  const pieData = [
    { name: 'تم التسليم', value: statusCounts['delivered'] || 0, color: '#10B981' },
    { name: 'مع المندوب', value: statusCounts['out_for_delivery'] || 0, color: '#F59E0B' },
    { name: 'في المستودع', value: statusCounts['in_hub'] || 0, color: '#3B82F6' },
    { name: 'جديدة', value: statusCounts['created'] || 0, color: '#8B5CF6' },
    { name: 'محاولة فاشلة', value: statusCounts['failed_attempt'] || 0, color: '#F43F5E' },
  ];

  // Aggregate by Governorate
  const govCounts = shipments.reduce((acc: Record<string, number>, s) => {
    const gov = s.recipient.governorate || 'القاهرة';
    acc[gov] = (acc[gov] || 0) + 1;
    return acc;
  }, {});

  const barData = Object.keys(govCounts).map((gov) => ({
    governorate: gov,
    shipmentsCount: govCounts[gov],
  }));

  return (
    <div className="space-y-6">
      {/* Analytics Header Banner */}
      <div className="bg-slate-900 text-white p-6 rounded-2xl border border-slate-800 flex items-center justify-between">
        <div>
          <h3 className="font-black text-xl flex items-center gap-2">
            <BarChart3 className="w-6 h-6 text-red-500" />
            تحليلات الأداء واللوجستيات المباشرة
          </h3>
          <p className="text-xs text-slate-400 mt-1">مؤشرات إنجاز العمليات وتوزيع الشحنات عبر المحافظات</p>
        </div>
        <div className="hidden sm:block text-left font-mono text-xs text-red-400 font-bold bg-slate-800 px-3 py-1.5 rounded-lg border border-slate-700">
          تحديث كلي فوري
        </div>
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Governorate Distribution Bar Chart */}
        <div className="bg-white border border-slate-200 p-6 rounded-2xl shadow-2xs space-y-4">
          <h4 className="font-extrabold text-sm text-slate-900">توزيع الشحنات حسب المحافظات المصرية</h4>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={barData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="governorate" tick={{ fontSize: 11 }} />
                <YAxis allowDecimals={false} tick={{ fontSize: 11 }} />
                <Tooltip />
                <Bar dataKey="shipmentsCount" fill="#DC2626" radius={[6, 6, 0, 0]} name="عدد الشحنات" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Status Distribution Pie Chart */}
        <div className="bg-white border border-slate-200 p-6 rounded-2xl shadow-2xs space-y-4">
          <h4 className="font-extrabold text-sm text-slate-900">نسب توزيع حالات الشحنات</h4>
          <div className="h-64 w-full flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};
