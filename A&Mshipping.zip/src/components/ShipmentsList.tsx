import React, { useState, useMemo } from 'react';
import { Shipment, ShipmentStatus, CourierInfo } from '../types';
import { EGYPT_GOVERNORATES, BOSTA_COURIERS } from '../data/mockData';
import { 
  Package, 
  Search, 
  Filter, 
  Printer, 
  Eye, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  Truck, 
  DollarSign, 
  MoreHorizontal, 
  TrendingUp, 
  FileSpreadsheet, 
  RotateCcw,
  Plus
} from 'lucide-react';

interface ShipmentsListProps {
  shipments: Shipment[];
  onOpenDetailModal: (shipment: Shipment) => void;
  onOpenPrintModal: (shipment: Shipment) => void;
  onOpenCreateModal: () => void;
  onUpdateStatus: (shipmentId: string, newStatus: ShipmentStatus) => void;
  onAssignCourier?: (shipmentId: string, courier: CourierInfo) => void;
}

export const ShipmentsList: React.FC<ShipmentsListProps> = ({
  shipments,
  onOpenDetailModal,
  onOpenPrintModal,
  onOpenCreateModal,
  onUpdateStatus,
  onAssignCourier,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [governorateFilter, setGovernorateFilter] = useState<string>('all');
  const [selectedIds, setSelectedIds] = useState<string[]>([]);

  // Filtered List
  const filteredShipments = useMemo(() => {
    return shipments.filter((s) => {
      // Search
      const searchLower = searchTerm.toLowerCase();
      const matchesSearch =
        s.trackingNumber.toLowerCase().includes(searchLower) ||
        s.recipient.name.toLowerCase().includes(searchLower) ||
        s.recipient.phone.includes(searchLower) ||
        s.recipient.streetAddress.toLowerCase().includes(searchLower) ||
        s.sender.storeName.toLowerCase().includes(searchLower);

      // Status
      const matchesStatus =
        statusFilter === 'all'
          ? true
          : statusFilter === 'active'
          ? ['created', 'pickup_requested', 'picked_up', 'in_hub', 'out_for_delivery'].includes(s.status)
          : statusFilter === 'delivered'
          ? s.status === 'delivered'
          : statusFilter === 'failed'
          ? s.status === 'failed_attempt'
          : statusFilter === 'returned'
          ? s.status === 'returned'
          : s.status === statusFilter;

      // Governorate
      const matchesGov =
        governorateFilter === 'all' ? true : s.recipient.governorate.includes(governorateFilter);

      return matchesSearch && matchesStatus && matchesGov;
    });
  }, [shipments, searchTerm, statusFilter, governorateFilter]);

  // Key KPI Metrics
  const totalCount = shipments.length;
  const deliveredCount = shipments.filter((s) => s.status === 'delivered').length;
  const activeCount = shipments.filter((s) =>
    ['created', 'pickup_requested', 'picked_up', 'in_hub', 'out_for_delivery'].includes(s.status)
  ).length;

  const totalCodCollected = shipments
    .filter((s) => s.status === 'delivered')
    .reduce((sum, s) => sum + s.financials.codAmount, 0);

  const successRate = totalCount > 0 ? Math.round((deliveredCount / totalCount) * 100) : 100;

  // Toggle selection
  const toggleSelectAll = () => {
    if (selectedIds.length === filteredShipments.length) {
      setSelectedIds([]);
    } else {
      setSelectedIds(filteredShipments.map((s) => s.id));
    }
  };

  const toggleSelectOne = (id: string) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const getStatusBadge = (status: ShipmentStatus) => {
    switch (status) {
      case 'delivered':
        return <span className="bg-emerald-100 text-emerald-800 font-bold text-xs px-2.5 py-1 rounded-full border border-emerald-200">تم التسليم</span>;
      case 'out_for_delivery':
        return <span className="bg-amber-100 text-amber-800 font-bold text-xs px-2.5 py-1 rounded-full border border-amber-200 flex items-center gap-1 w-fit"><Truck className="w-3 h-3 animate-pulse" /> مع المندوب</span>;
      case 'in_hub':
        return <span className="bg-blue-100 text-blue-800 font-bold text-xs px-2.5 py-1 rounded-full border border-blue-200">في المستودع</span>;
      case 'picked_up':
        return <span className="bg-indigo-100 text-indigo-800 font-bold text-xs px-2.5 py-1 rounded-full border border-indigo-200">تم الاستلام</span>;
      case 'failed_attempt':
        return <span className="bg-rose-100 text-rose-800 font-bold text-xs px-2.5 py-1 rounded-full border border-rose-200">محاولة فاشلة</span>;
      case 'returned':
        return <span className="bg-purple-100 text-purple-800 font-bold text-xs px-2.5 py-1 rounded-full border border-purple-200">مرتجع</span>;
      case 'cancelled':
        return <span className="bg-slate-100 text-slate-600 font-bold text-xs px-2.5 py-1 rounded-full">ملغاة</span>;
      default:
        return <span className="bg-slate-100 text-slate-800 font-bold text-xs px-2.5 py-1 rounded-full border border-slate-200">جديدة</span>;
    }
  };

  return (
    <div className="space-y-6">
      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-2xs hover:border-slate-300 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500">إجمالي الشحنات</span>
            <div className="w-8 h-8 rounded-lg bg-red-50 text-red-600 flex items-center justify-center">
              <Package className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-black text-slate-900 mt-2">{totalCount}</p>
          <p className="text-[11px] text-slate-500 mt-1">شحنة مسجلة في النظام</p>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-2xs hover:border-slate-300 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500">قيد التسليم اليوم</span>
            <div className="w-8 h-8 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center">
              <Truck className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-black text-amber-600 mt-2">{activeCount}</p>
          <p className="text-[11px] text-slate-500 mt-1">طرد مع المندوبين/المستودعات</p>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-2xs hover:border-slate-300 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500">إجمالي تحصيل COD</span>
            <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-black text-emerald-600 mt-2">{totalCodCollected.toLocaleString()} ج.م</p>
          <p className="text-[11px] text-slate-500 mt-1">مبالغ تم استلامها كاش</p>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-2xs hover:border-slate-300 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500">نسبة نجاح التسليم</span>
            <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-black text-blue-600 mt-2">{successRate}%</p>
          <p className="text-[11px] text-slate-500 mt-1">معدل الإنجاز العالي</p>
        </div>
      </div>

      {/* Control Toolbar */}
      <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-2xs space-y-4">
        <div className="flex flex-col lg:flex-row items-center justify-between gap-4">
          {/* Status Tabs */}
          <div className="flex items-center gap-1 overflow-x-auto w-full lg:w-auto pb-2 lg:pb-0 scrollbar-none">
            <button
              onClick={() => setStatusFilter('all')}
              className={`px-3 py-1.5 rounded-lg text-xs font-extrabold whitespace-nowrap transition-all ${
                statusFilter === 'all'
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              جميع الشحنات ({totalCount})
            </button>

            <button
              onClick={() => setStatusFilter('active')}
              className={`px-3 py-1.5 rounded-lg text-xs font-extrabold whitespace-nowrap transition-all ${
                statusFilter === 'active'
                  ? 'bg-amber-600 text-white shadow-xs'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              قيد الشحن والتوزيع ({activeCount})
            </button>

            <button
              onClick={() => setStatusFilter('delivered')}
              className={`px-3 py-1.5 rounded-lg text-xs font-extrabold whitespace-nowrap transition-all ${
                statusFilter === 'delivered'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              تم التسليم ({deliveredCount})
            </button>

            <button
              onClick={() => setStatusFilter('failed')}
              className={`px-3 py-1.5 rounded-lg text-xs font-extrabold whitespace-nowrap transition-all ${
                statusFilter === 'failed'
                  ? 'bg-rose-600 text-white shadow-xs'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              محاولات فاشلة
            </button>

            <button
              onClick={() => setStatusFilter('returned')}
              className={`px-3 py-1.5 rounded-lg text-xs font-extrabold whitespace-nowrap transition-all ${
                statusFilter === 'returned'
                  ? 'bg-purple-600 text-white shadow-xs'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              مرتجعات
            </button>
          </div>

          {/* Create CTA Button */}
          <button
            onClick={onOpenCreateModal}
            className="w-full lg:w-auto bg-red-600 hover:bg-red-700 text-white font-extrabold text-xs px-4 py-2 rounded-xl shadow-xs transition-colors flex items-center justify-center gap-2"
          >
            <Plus className="w-4 h-4" />
            إنشاء شحنة جديدة
          </button>
        </div>

        {/* Search & Governorate Filters Row */}
        <div className="flex flex-col sm:flex-row items-center gap-3 pt-2 border-t border-slate-100">
          <div className="relative w-full sm:w-80">
            <input
              type="text"
              placeholder="ابحث برقم البوليصة، اسم المستلم، الهاتف..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pr-9 pl-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:outline-none focus:ring-2 focus:ring-red-500/20"
            />
            <Search className="w-4 h-4 text-slate-400 absolute right-3 top-2.5" />
          </div>

          <div className="w-full sm:w-auto flex items-center gap-2">
            <Filter className="w-4 h-4 text-slate-400 shrink-0" />
            <select
              value={governorateFilter}
              onChange={(e) => setGovernorateFilter(e.target.value)}
              className="w-full sm:w-48 text-xs p-2 bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-700 focus:bg-white"
            >
              <option value="all">جميع المحافظات</option>
              {EGYPT_GOVERNORATES.map((g) => (
                <option key={g.code} value={g.nameAr}>
                  {g.nameAr}
                </option>
              ))}
            </select>
          </div>

          {/* Bulk Selection Actions */}
          {selectedIds.length > 0 && (
            <div className="flex items-center gap-2 text-xs font-bold text-slate-800 bg-red-50 border border-red-200 px-3 py-1.5 rounded-xl w-full sm:w-auto justify-between sm:justify-start">
              <span>تم تحديد {selectedIds.length} شحنات</span>
              <button
                onClick={() => {
                  const firstSelected = shipments.find((s) => s.id === selectedIds[0]);
                  if (firstSelected) onOpenPrintModal(firstSelected);
                }}
                className="text-red-700 hover:underline flex items-center gap-1"
              >
                <Printer className="w-3.5 h-3.5" /> طباعة البوالص
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Shipments Table */}
      <div className="bg-white border border-slate-200 rounded-2xl shadow-2xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-right text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-extrabold uppercase">
              <tr>
                <th className="p-3 text-center">
                  <input
                    type="checkbox"
                    checked={selectedIds.length === filteredShipments.length && filteredShipments.length > 0}
                    onChange={toggleSelectAll}
                    className="w-4 h-4 text-red-600 rounded border-slate-300"
                  />
                </th>
                <th className="p-3">رقم البوليصة (AWB)</th>
                <th className="p-3">المستلم والعنوان</th>
                <th className="p-3">المحافظة والمستودع</th>
                <th className="p-3">المندوب المخصص</th>
                <th className="p-3">المبلغ (COD)</th>
                <th className="p-3">المعايينة والنوع</th>
                <th className="p-3">حالة الشحنة</th>
                <th className="p-3 text-center">إجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredShipments.length === 0 ? (
                <tr>
                  <td colSpan={8} className="p-8 text-center text-slate-500 font-medium">
                    لا توجد شحنات مطابقة لخيارات البحث المحددة.
                  </td>
                </tr>
              ) : (
                filteredShipments.map((s) => (
                  <tr key={s.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="p-3 text-center">
                      <input
                        type="checkbox"
                        checked={selectedIds.includes(s.id)}
                        onChange={() => toggleSelectOne(s.id)}
                        className="w-4 h-4 text-red-600 rounded border-slate-300"
                      />
                    </td>
                    <td className="p-3 font-mono font-black text-slate-900">
                      <span 
                        onClick={() => onOpenDetailModal(s)}
                        className="cursor-pointer hover:text-red-600 transition-colors"
                      >
                        {s.trackingNumber}
                      </span>
                      <span className="block text-[10px] text-slate-400 font-sans font-normal mt-0.5">
                        {new Date(s.createdAt).toLocaleDateString('ar-EG')}
                      </span>
                    </td>
                    <td className="p-3">
                      <p className="font-extrabold text-slate-900">{s.recipient.name}</p>
                      <p className="text-[11px] text-slate-500 font-mono" dir="ltr">{s.recipient.phone}</p>
                      <p className="text-[11px] text-slate-600 truncate max-w-[200px]">{s.recipient.streetAddress}</p>
                    </td>
                    <td className="p-3">
                      <span className="font-bold text-slate-800 block">{s.recipient.governorate}</span>
                      <span className="text-[11px] text-slate-500 block truncate max-w-[150px]">{s.assignedHub}</span>
                    </td>
                    <td className="p-3">
                      {s.assignedCourier ? (
                        <div className="flex items-center gap-1.5 mb-1">
                          <span className="w-5 h-5 rounded-full bg-red-100 text-red-600 flex items-center justify-center text-[10px] font-bold shrink-0">
                            <Truck className="w-3 h-3" />
                          </span>
                          <span className="font-bold text-slate-800 text-xs truncate max-w-[110px]">{s.assignedCourier.name}</span>
                        </div>
                      ) : (
                        <span className="text-[10px] text-slate-400 font-medium block mb-1">غير مسند</span>
                      )}
                      {onAssignCourier && (
                        <select
                          value={s.assignedCourier?.id || ''}
                          onChange={(e) => {
                            const found = BOSTA_COURIERS.find((c) => c.id === e.target.value);
                            if (found) onAssignCourier(s.id, found);
                          }}
                          className="text-[10px] p-1 bg-slate-100 border border-slate-200 rounded text-slate-700 font-bold block w-full focus:bg-white cursor-pointer"
                        >
                          <option value="">-- تعيين مندوب --</option>
                          {BOSTA_COURIERS.map((c) => (
                            <option key={c.id} value={c.id}>
                              {c.name}
                            </option>
                          ))}
                        </select>
                      )}
                    </td>
                    <td className="p-3">
                      <span className="font-extrabold text-red-600 block text-sm">
                        {s.financials.codAmount.toLocaleString()} ج.م
                      </span>
                      <span className="text-[10px] text-slate-400 block">
                        الصافي: {s.financials.netPayout.toLocaleString()} ج.م
                      </span>
                    </td>
                    <td className="p-3">
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded border inline-block ${
                        s.packageDetails.allowOpening
                          ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                          : 'bg-slate-100 text-slate-600 border-slate-200'
                      }`}>
                        {s.packageDetails.allowOpening ? 'معاينة مسموحة' : 'ممنوع الفتح'}
                      </span>
                      <span className="text-[10px] text-slate-500 block mt-0.5">
                        {s.packageDetails.weightKg} كجم ({s.packageDetails.itemsCount} قطعة)
                      </span>
                    </td>
                    <td className="p-3">{getStatusBadge(s.status)}</td>
                    <td className="p-3 text-center">
                      <div className="flex items-center justify-center gap-1">
                        <button
                          onClick={() => onOpenPrintModal(s)}
                          title="طباعة البوليصة"
                          className="p-1.5 text-slate-600 hover:text-red-600 hover:bg-slate-100 rounded-lg transition-colors"
                        >
                          <Printer className="w-4 h-4" />
                        </button>

                        <button
                          onClick={() => onOpenDetailModal(s)}
                          title="عرض التفاصيل والتاريخ"
                          className="p-1.5 text-slate-600 hover:text-red-600 hover:bg-slate-100 rounded-lg transition-colors"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
