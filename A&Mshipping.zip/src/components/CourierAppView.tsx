import React, { useState, useEffect } from 'react';
import { Shipment, CourierInfo, ShipmentStatus, CourierNotification } from '../types';
import { BOSTA_COURIERS } from '../data/mockData';
import { 
  Truck, 
  Phone, 
  MapPin, 
  DollarSign, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  ShieldCheck, 
  KeyRound, 
  Package, 
  Navigation,
  UserCheck,
  Building,
  Bell,
  Check,
  Sparkles,
  X,
  ChevronDown
} from 'lucide-react';

interface CourierAppViewProps {
  shipments: Shipment[];
  onUpdateStatus: (shipmentId: string, newStatus: ShipmentStatus, note?: string) => void;
  notifications?: CourierNotification[];
  selectedCourierId?: string;
  targetShipmentId?: string;
  onMarkNotificationRead?: (notificationId: string) => void;
}

export const CourierAppView: React.FC<CourierAppViewProps> = ({
  shipments,
  onUpdateStatus,
  notifications = [],
  selectedCourierId,
  targetShipmentId,
  onMarkNotificationRead,
}) => {
  const [activeCourier, setActiveCourier] = useState<CourierInfo>(BOSTA_COURIERS[1]);
  const [selectedShipment, setSelectedShipment] = useState<Shipment | null>(null);
  const [pinInput, setPinInput] = useState('');
  const [failedReason, setFailedReason] = useState('لم يقم بالرد على الهاتف');
  const [isDeliverModalOpen, setIsDeliverModalOpen] = useState(false);
  const [isFailModalOpen, setIsFailModalOpen] = useState(false);
  const [isNotifPanelOpen, setIsNotifPanelOpen] = useState(false);
  const [highlightedShipmentId, setHighlightedShipmentId] = useState<string | undefined>(targetShipmentId);

  // Sync active courier if selected from parent / notification
  useEffect(() => {
    if (selectedCourierId) {
      const found = BOSTA_COURIERS.find((c) => c.id === selectedCourierId);
      if (found) setActiveCourier(found);
    }
  }, [selectedCourierId]);

  useEffect(() => {
    if (targetShipmentId) {
      setHighlightedShipmentId(targetShipmentId);
    }
  }, [targetShipmentId]);

  // Notifications for current active courier
  const courierNotifs = notifications.filter((n) => n.courierId === activeCourier.id);
  const unreadCount = courierNotifs.filter((n) => !n.read).length;

  // Deliveries assigned to selected courier or active
  const courierShipments = shipments.filter(
    (s) => s.assignedCourier?.id === activeCourier.id || s.status === 'out_for_delivery'
  );

  const totalCodCollectedToday = courierShipments
    .filter((s) => s.status === 'delivered')
    .reduce((sum, s) => sum + s.financials.codAmount, 0);

  const handleConfirmDelivery = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedShipment) return;

    onUpdateStatus(
      selectedShipment.id,
      'delivered',
      `تم التسليم بنجاح بترميز التأكيد (${pinInput || '8492'}) وتحصيل المبلغ ${selectedShipment.financials.codAmount} ج.م`
    );

    setIsDeliverModalOpen(false);
    setSelectedShipment(null);
    setPinInput('');
  };

  const handleConfirmFailed = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedShipment) return;

    onUpdateStatus(selectedShipment.id, 'failed_attempt', `محاولة تسليم غير ناجحة: ${failedReason}`);

    setIsFailModalOpen(false);
    setSelectedShipment(null);
  };

  return (
    <div className="max-w-md mx-auto bg-slate-900 text-slate-100 rounded-3xl border-4 border-slate-800 shadow-2xl overflow-hidden my-4 min-h-[720px] flex flex-col relative">
      {/* Mobile Top Bar */}
      <div className="bg-slate-950 p-4 border-b border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <img
            src={activeCourier.photoUrl}
            alt={activeCourier.name}
            className="w-10 h-10 rounded-full border-2 border-red-500 object-cover"
          />
          <div>
            <h3 className="font-extrabold text-sm text-white">{activeCourier.name}</h3>
            <p className="text-[11px] text-slate-400">كابتن توصيل | {activeCourier.assignedHub}</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Notification Bell Icon */}
          <button
            onClick={() => setIsNotifPanelOpen(!isNotifPanelOpen)}
            className="relative p-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl border border-slate-700 transition-colors"
            title="تنبيهات وإشعارات المندوب"
          >
            <Bell className="w-4 h-4 text-amber-400" />
            {unreadCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-red-600 text-white text-[10px] font-black w-4 h-4 rounded-full flex items-center justify-center animate-pulse">
                {unreadCount}
              </span>
            )}
          </button>

          {/* Courier Selector */}
          <select
            value={activeCourier.id}
            onChange={(e) => {
              const found = BOSTA_COURIERS.find((c) => c.id === e.target.value);
              if (found) setActiveCourier(found);
            }}
            className="bg-slate-800 text-white text-[10px] p-1.5 rounded-lg border border-slate-700 font-bold"
          >
            {BOSTA_COURIERS.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Notification Center Drawer overlay */}
      {isNotifPanelOpen && (
        <div className="absolute top-[68px] inset-x-0 bg-slate-900/95 backdrop-blur-md z-40 border-b-2 border-red-500 shadow-2xl p-4 space-y-3 animate-in slide-in-from-top-3 duration-200">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <span className="text-xs font-black text-white flex items-center gap-1.5">
              <Bell className="w-4 h-4 text-red-500" />
              مركز إشعارات الشحنات الموكلة ({courierNotifs.length})
            </span>
            <button onClick={() => setIsNotifPanelOpen(false)} className="text-slate-400 hover:text-white text-xs">
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="max-h-60 overflow-y-auto space-y-2">
            {courierNotifs.length === 0 ? (
              <div className="text-center py-6 text-slate-500 text-xs">
                لا توجد إشعارات تكليف جديدة حالياً
              </div>
            ) : (
              courierNotifs.map((n) => (
                <div
                  key={n.id}
                  onClick={() => {
                    setHighlightedShipmentId(n.shipmentId);
                    if (onMarkNotificationRead) onMarkNotificationRead(n.id);
                    setIsNotifPanelOpen(false);
                  }}
                  className={`p-2.5 rounded-xl border cursor-pointer transition-all ${
                    !n.read
                      ? 'bg-red-950/40 border-red-500/60 text-white'
                      : 'bg-slate-800/80 border-slate-700/80 text-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between text-xs font-bold">
                    <span className="text-red-400 font-mono">#{n.trackingNumber}</span>
                    <span className="text-[10px] text-slate-400">{n.timestamp}</span>
                  </div>
                  <p className="text-xs font-medium text-slate-200 mt-1">
                    تم إسناد الشحنة لك تسليم العميل <span className="font-bold text-white">{n.recipientName}</span> ({n.governorate})
                  </p>
                  <div className="flex items-center justify-between mt-2 pt-1.5 border-t border-slate-800 text-[11px]">
                    <span className="text-emerald-400 font-bold">المطلوب: {n.codAmount.toLocaleString()} ج.م</span>
                    <span className="text-slate-400 hover:text-red-400 flex items-center gap-1">
                      عرض الشحنة ←
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* Daily Cash Collection Header Pill */}
      <div className="bg-gradient-to-r from-red-600 to-red-700 p-4 text-white flex items-center justify-between shadow-md">
        <div>
          <span className="text-[10px] text-red-100 block">إجمالي التحصيل اليومي المباشر:</span>
          <span className="text-2xl font-black">{totalCodCollectedToday.toLocaleString()} <span className="text-xs">ج.م</span></span>
        </div>
        <div className="text-left bg-black/20 p-2 rounded-xl border border-white/10">
          <span className="text-[10px] text-red-100 block">الطلبات المتبقية:</span>
          <span className="text-lg font-black text-center block">
            {courierShipments.filter((s) => s.status === 'out_for_delivery').length}
          </span>
        </div>
      </div>

      {/* Deliveries List */}
      <div className="p-4 space-y-4 flex-1 overflow-y-auto">
        <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center justify-between">
          <span>طلبات الشحنات الموكلة إليك اليوم:</span>
          <span className="text-red-400 font-mono">{courierShipments.length} طرد</span>
        </h4>

        {courierShipments.length === 0 ? (
          <div className="text-center py-12 text-slate-500 text-xs">
            لا توجد شحنات مسندة إليك حالياً.
          </div>
        ) : (
          courierShipments.map((shipment) => {
            const isHighlighted = highlightedShipmentId === shipment.id;
            const hasNotif = courierNotifs.some((n) => n.shipmentId === shipment.id);

            return (
              <div
                key={shipment.id}
                className={`p-4 rounded-2xl border transition-all space-y-3 ${
                  isHighlighted
                    ? 'bg-slate-800 border-2 border-red-500 ring-2 ring-red-500/30'
                    : shipment.status === 'delivered'
                    ? 'bg-emerald-950/40 border-emerald-500/40'
                    : shipment.status === 'failed_attempt'
                    ? 'bg-rose-950/40 border-rose-500/40'
                    : 'bg-slate-800 border-slate-700 hover:border-red-500/50'
                }`}
              >
                {/* Notification Badge if freshly assigned */}
                {hasNotif && (
                  <div className="flex items-center gap-1.5 text-[10px] font-bold text-amber-300 bg-amber-950/80 px-2.5 py-1 rounded-lg border border-amber-500/50 w-fit">
                    <Sparkles className="w-3 h-3 text-amber-400 animate-spin" />
                    <span>تم إسناد هذه الشحنة لك حديثاً</span>
                  </div>
                )}

                {/* Top row */}
                <div className="flex items-center justify-between">
                  <span className="font-mono font-black text-xs text-red-400 bg-red-950/80 px-2 py-0.5 rounded border border-red-800">
                    {shipment.trackingNumber}
                  </span>
                  <span className="text-[11px] font-bold px-2 py-0.5 rounded text-white bg-slate-700">
                    {shipment.financials.codAmount.toLocaleString()} ج.م (كاش)
                  </span>
                </div>

                {/* Customer details */}
                <div>
                  <h5 className="font-extrabold text-sm text-white">{shipment.recipient.name}</h5>
                  <p className="text-xs text-slate-300 mt-1 flex items-start gap-1">
                    <MapPin className="w-3.5 h-3.5 text-red-400 shrink-0 mt-0.5" />
                    {shipment.recipient.governorate} - {shipment.recipient.city} - {shipment.recipient.streetAddress}
                  </p>
                  {shipment.recipient.notes && (
                    <p className="text-[10px] text-amber-300 bg-amber-950/60 p-1.5 rounded mt-1 border border-amber-800/50">
                      ملاحظات: {shipment.recipient.notes}
                    </p>
                  )}
                </div>

                {/* Call Customer Button */}
                <div className="flex items-center gap-2">
                  <a
                    href={`tel:${shipment.recipient.phone}`}
                    className="flex-1 bg-slate-700 hover:bg-slate-600 text-white text-xs font-bold py-2 rounded-xl text-center flex items-center justify-center gap-1.5 transition-colors"
                  >
                    <Phone className="w-3.5 h-3.5 text-emerald-400" />
                    اتصال بالعميل ({shipment.recipient.phone})
                  </a>
                </div>

                {/* Actions for active items */}
                {shipment.status === 'out_for_delivery' && (
                  <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-700">
                    <button
                      onClick={() => {
                        setSelectedShipment(shipment);
                        setIsDeliverModalOpen(true);
                      }}
                      className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs py-2 rounded-xl flex items-center justify-center gap-1 shadow-sm transition-colors"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      تسليم الكاش
                    </button>

                    <button
                      onClick={() => {
                        setSelectedShipment(shipment);
                        setIsFailModalOpen(true);
                      }}
                      className="bg-rose-900/60 hover:bg-rose-800 text-rose-200 border border-rose-700/60 font-bold text-xs py-2 rounded-xl flex items-center justify-center gap-1 transition-colors"
                    >
                      <XCircle className="w-3.5 h-3.5" />
                      محاولة فاشلة
                    </button>
                  </div>
                )}

                {/* Status Indicator */}
                {shipment.status === 'delivered' && (
                  <div className="text-[11px] text-emerald-400 font-bold flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" /> تم التسليم بنجاح وتحصيل المبلغ
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* Deliver Modal */}
      {isDeliverModalOpen && selectedShipment && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-sm w-full p-6 space-y-4">
            <h4 className="font-extrabold text-base text-white flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-emerald-400" />
              تأكيد تسليم الشحنة وتحصيل الكاش
            </h4>

            <div className="bg-slate-800 p-3 rounded-xl space-y-1 text-xs text-slate-300">
              <p>المستلم: <span className="font-bold text-white">{selectedShipment.recipient.name}</span></p>
              <p>المبلغ المطلوب تحصيله: <span className="font-black text-emerald-400 text-sm">{selectedShipment.financials.codAmount} ج.م</span></p>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">رمز التحقق / PIN العميل (اختياري)</label>
              <input
                type="text"
                placeholder="أدخل PIN المتسلم مثلاً: 8492"
                value={pinInput}
                onChange={(e) => setPinInput(e.target.value)}
                className="w-full text-xs p-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white font-mono text-center tracking-widest text-lg"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setIsDeliverModalOpen(false)}
                className="px-3 py-1.5 text-xs font-bold text-slate-400"
              >
                إلغاء
              </button>
              <button
                onClick={handleConfirmDelivery}
                className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs px-4 py-2 rounded-xl"
              >
                تأكيد وتسجيل الكاش
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Failed Modal */}
      {isFailModalOpen && selectedShipment && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-sm w-full p-6 space-y-4">
            <h4 className="font-extrabold text-base text-rose-400 flex items-center gap-2">
              <XCircle className="w-5 h-5 text-rose-500" />
              تسجيل سبب عدم التسليم
            </h4>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">السبب:</label>
              <select
                value={failedReason}
                onChange={(e) => setFailedReason(e.target.value)}
                className="w-full text-xs p-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white font-bold"
              >
                <option value="لم يقم بالرد على الهاتف">لم يقم بالرد على الهاتف</option>
                <option value="العميل طلب التأجيل ليوم آخر">العميل طلب التأجيل ليوم آخر</option>
                <option value="رفض الاستلام بسبب السعر">رفض الاستلام بسبب السعر</option>
                <option value="العنوان غير واضح أو خاطئ">العنوان غير واضح أو خاطئ</option>
              </select>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setIsFailModalOpen(false)}
                className="px-3 py-1.5 text-xs font-bold text-slate-400"
              >
                إلغاء
              </button>
              <button
                onClick={handleConfirmFailed}
                className="bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs px-4 py-2 rounded-xl"
              >
                تسجيل المحاولة الفاشلة
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
