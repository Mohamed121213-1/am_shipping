import React, { useState } from 'react';
import { Shipment, ShipmentStatus, CourierInfo } from '../types';
import { BOSTA_COURIERS } from '../data/mockData';
import { X, CheckCircle2, Clock, MapPin, Truck, AlertTriangle, ShieldCheck, Sparkles, Printer, User, Phone, Package, DollarSign, ArrowRight, KeyRound } from 'lucide-react';

interface ShipmentDetailModalProps {
  shipment: Shipment | null;
  onClose: () => void;
  onUpdateStatus: (shipmentId: string, newStatus: ShipmentStatus, note?: string) => void;
  onAssignCourier: (shipmentId: string, courier: CourierInfo) => void;
  onOpenPrintModal: (shipment: Shipment) => void;
}

export const ShipmentDetailModal: React.FC<ShipmentDetailModalProps> = ({
  shipment,
  onClose,
  onUpdateStatus,
  onAssignCourier,
  onOpenPrintModal,
}) => {
  if (!shipment) return null;

  const [statusNote, setStatusNote] = useState('');
  const [selectedCourierId, setSelectedCourierId] = useState(shipment.assignedCourier?.id || '');
  const [selectedStatus, setSelectedStatus] = useState<ShipmentStatus>(shipment.status);

  // AI Risk Check state
  const [isAiRiskChecking, setIsAiRiskChecking] = useState(false);
  const [aiRiskResult, setAiRiskResult] = useState<{ riskScore?: number; riskLevel?: string; recommendations?: string[] } | null>(null);

  const handleStatusChangeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateStatus(shipment.id, selectedStatus, statusNote);
    setStatusNote('');
  };

  const handleCourierAssign = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const courierId = e.target.value;
    setSelectedCourierId(courierId);
    const found = BOSTA_COURIERS.find((c) => c.id === courierId);
    if (found) {
      onAssignCourier(shipment.id, found);
    }
  };

  const runAiRiskCheck = async () => {
    setIsAiRiskChecking(true);
    try {
      const res = await fetch('/api/ai-risk-check', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ shipment }),
      });
      const data = await res.json();
      setAiRiskResult(data);
    } catch (e) {
      console.error(e);
    } finally {
      setIsAiRiskChecking(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl max-w-4xl w-full border border-slate-200 overflow-hidden my-8">
        {/* Header */}
        <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-red-600 flex items-center justify-center font-mono font-black text-white text-sm">
              AWB
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-mono font-extrabold text-lg text-white">{shipment.trackingNumber}</h3>
                <span className="bg-red-500/20 text-red-400 border border-red-500/30 font-bold text-[10px] px-2 py-0.5 rounded">
                  {shipment.deliveryType === 'express' ? '⚡ شحن سريع' : '📦 شحن عادي'}
                </span>
              </div>
              <p className="text-xs text-slate-400">تاريخ الإنشاء: {new Date(shipment.createdAt).toLocaleString('ar-EG')}</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => onOpenPrintModal(shipment)}
              className="bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold px-3 py-1.5 rounded-lg flex items-center gap-1.5 border border-slate-700"
            >
              <Printer className="w-4 h-4 text-red-400" />
              طباعة البوليصة
            </button>
            <button onClick={onClose} className="text-slate-400 hover:text-white p-1 rounded-lg">
              <X className="w-6 h-6" />
            </button>
          </div>
        </div>

        <div className="p-6 space-y-6 max-h-[80vh] overflow-y-auto text-slate-900">
          {/* Timeline Status Stepper */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-4">
            <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-4 flex items-center justify-between">
              <span>مسار وحالة الشحنة الحالية (Shipment Timeline):</span>
              <span className="font-mono font-extrabold text-red-600 bg-red-50 px-2 py-0.5 rounded border border-red-200">
                {shipment.status === 'delivered' ? '✅ تم التسليم' : shipment.status === 'out_for_delivery' ? '🚚 مع المندوب للتسليم' : shipment.status === 'in_hub' ? '🏬 في المستودع' : shipment.status === 'picked_up' ? '📦 تم الاستلام' : '📝 تم إنشاء البوليصة'}
              </span>
            </h4>

            {/* Stepper Display */}
            <div className="relative border-r-2 border-slate-300 mr-4 pr-6 space-y-6">
              {shipment.timeline.map((event, idx) => (
                <div key={event.id || idx} className="relative">
                  <div className="absolute -right-[31px] top-0 w-4 h-4 rounded-full bg-red-600 border-2 border-white shadow-xs flex items-center justify-center">
                    <div className="w-1.5 h-1.5 rounded-full bg-white"></div>
                  </div>

                  <div className="bg-white p-3 rounded-lg border border-slate-200 shadow-2xs">
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-extrabold text-xs text-slate-900">{event.title}</span>
                      <span className="text-[10px] text-slate-500 font-mono">{event.timestamp}</span>
                    </div>
                    <p className="text-xs text-slate-600 mt-1">{event.description}</p>
                    {event.location && (
                      <span className="inline-flex items-center gap-1 text-[11px] text-red-600 font-semibold mt-1">
                        <MapPin className="w-3 h-3" />
                        {event.location}
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Recipient & Package Details Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Recipient Card */}
            <div className="border border-slate-200 rounded-xl p-4 bg-white shadow-2xs">
              <h5 className="font-bold text-xs text-slate-500 mb-2 flex items-center gap-1.5 border-b border-slate-100 pb-2">
                <User className="w-4 h-4 text-red-600" />
                بيانات المستلم والعنوان
              </h5>
              <p className="font-extrabold text-sm text-slate-900">{shipment.recipient.name}</p>
              <p className="text-xs font-mono font-bold text-slate-700 mt-0.5" dir="ltr">{shipment.recipient.phone}</p>
              <p className="text-xs text-slate-700 mt-2 font-medium">
                📍 {shipment.recipient.governorate} - {shipment.recipient.city} - {shipment.recipient.streetAddress}
              </p>
              {shipment.recipient.notes && (
                <div className="mt-2 text-xs text-amber-800 bg-amber-50 p-2 rounded border border-amber-200">
                  ملاحظات: {shipment.recipient.notes}
                </div>
              )}
            </div>

            {/* Financials & Courier Card */}
            <div className="border border-slate-200 rounded-xl p-4 bg-white shadow-2xs space-y-3">
              <h5 className="font-bold text-xs text-slate-500 border-b border-slate-100 pb-2 flex items-center gap-1.5">
                <DollarSign className="w-4 h-4 text-emerald-600" />
                الماليات والمندوب المخصص
              </h5>

              <div className="grid grid-cols-2 gap-2 text-center bg-slate-50 p-2 rounded-lg">
                <div>
                  <span className="text-[10px] text-slate-500 block">المبلغ المطلوب (COD):</span>
                  <span className="text-sm font-extrabold text-red-600">{shipment.financials.codAmount.toLocaleString()} ج.م</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 block">صافي التاجر:</span>
                  <span className="text-sm font-extrabold text-emerald-600">{shipment.financials.netPayout.toLocaleString()} ج.م</span>
                </div>
              </div>

              {/* Courier Selector */}
              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">تعيين المندوب المسؤول:</label>
                <select
                  value={selectedCourierId}
                  onChange={handleCourierAssign}
                  className="w-full text-xs p-2 bg-slate-100 border border-slate-200 rounded-lg font-bold text-slate-800 focus:bg-white"
                >
                  <option value="">-- اختر المندوب --</option>
                  {BOSTA_COURIERS.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name} ({c.assignedHub})
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          {/* AI Risk Check Trigger Box */}
          <div className="border border-purple-200 rounded-xl p-4 bg-gradient-to-r from-purple-50 to-indigo-50">
            <div className="flex items-center justify-between mb-2">
              <span className="font-bold text-xs text-purple-900 flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-purple-600" />
                تحليل مخاطر التسليم بالذكاء الاصطناعي (AI Risk Check)
              </span>
              <button
                type="button"
                onClick={runAiRiskCheck}
                disabled={isAiRiskChecking}
                className="bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold px-3 py-1.5 rounded-lg transition-colors flex items-center gap-1"
              >
                {isAiRiskChecking ? 'جاري التحليل...' : 'فحص الشحنة'}
              </button>
            </div>

            {aiRiskResult && (
              <div className="mt-3 bg-white p-3 rounded-lg border border-purple-200 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-700">مستوى المخاطرة التقديري:</span>
                  <span className={`text-xs font-black px-2 py-0.5 rounded ${
                    (aiRiskResult.riskScore || 0) > 40 ? 'bg-red-100 text-red-700' : 'bg-emerald-100 text-emerald-700'
                  }`}>
                    {aiRiskResult.riskLevel} ({aiRiskResult.riskScore}%)
                  </span>
                </div>
                {aiRiskResult.recommendations && (
                  <ul className="text-xs text-slate-600 space-y-1 list-disc list-inside">
                    {aiRiskResult.recommendations.map((rec, i) => (
                      <li key={i}>{rec}</li>
                    ))}
                  </ul>
                )}
              </div>
            )}
          </div>

          {/* Fast Status Updater Control */}
          <form onSubmit={handleStatusChangeSubmit} className="bg-slate-900 text-white p-4 rounded-xl space-y-3">
            <h5 className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
              <Clock className="w-4 h-4 text-red-400" />
              تحديث حالة الشحنة فوراً
            </h5>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <select
                  value={selectedStatus}
                  onChange={(e) => setSelectedStatus(e.target.value as ShipmentStatus)}
                  className="w-full text-xs p-2 bg-slate-800 border border-slate-700 rounded-lg text-white font-bold"
                >
                  <option value="created">تم إنشاء الشحنة</option>
                  <option value="pickup_requested">طلب استلام من التاجر</option>
                  <option value="picked_up">تم الاستلام من التاجر</option>
                  <option value="in_hub">في المستودع الرئيسي</option>
                  <option value="out_for_delivery">خرجت للتسليم مع المندوب</option>
                  <option value="delivered">تم التسليم للعميل وتحصيل المبلغ</option>
                  <option value="failed_attempt">محاولة تسليم فاشلة</option>
                  <option value="returned">مرتجع للتاجر</option>
                  <option value="cancelled">ملغاة</option>
                </select>
              </div>

              <div>
                <input
                  type="text"
                  placeholder="ملاحظات الحالة (مثال: تم الاتصال والعميل غير متاح)..."
                  value={statusNote}
                  onChange={(e) => setStatusNote(e.target.value)}
                  className="w-full text-xs p-2 bg-slate-800 border border-slate-700 rounded-lg text-white"
                />
              </div>

              <div>
                <button
                  type="submit"
                  className="w-full bg-red-600 hover:bg-red-700 text-white font-bold text-xs p-2 rounded-lg transition-colors"
                >
                  حفظ التحديث
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
