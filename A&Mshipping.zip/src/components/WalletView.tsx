import React, { useState } from 'react';
import { MerchantWallet, Shipment } from '../types';
import { Wallet, ArrowDownLeft, Landmark, Smartphone, CheckCircle, Clock, DollarSign, ArrowUpRight, ShieldCheck } from 'lucide-react';

interface WalletViewProps {
  wallet: MerchantWallet;
  shipments: Shipment[];
  onRequestPayout: (amount: number, method: string) => void;
}

export const WalletView: React.FC<WalletViewProps> = ({ wallet, shipments, onRequestPayout }) => {
  const [payoutAmount, setPayoutAmount] = useState<number>(wallet.availableBalance);
  const [payoutMethod, setPayoutMethod] = useState<'instapay' | 'vodafone' | 'bank'>('instapay');
  const [payoutSuccessMsg, setPayoutSuccessMsg] = useState('');

  const deliveredShipments = shipments.filter((s) => s.status === 'delivered');

  const handlePayoutSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (payoutAmount <= 0 || payoutAmount > wallet.availableBalance) {
      alert('الرجاء إدخال مبلغ صحيح ضمن الرصيد المتاح للسحب');
      return;
    }

    onRequestPayout(payoutAmount, payoutMethod);
    setPayoutSuccessMsg(`تم إرسال طلب السحب بنجاح بمبلغ ${payoutAmount.toLocaleString()} ج.م عبر ${payoutMethod.toUpperCase()}`);
    setTimeout(() => setPayoutSuccessMsg(''), 5000);
  };

  return (
    <div className="space-y-6">
      {/* Wallet Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Available Balance Box */}
        <div className="bg-gradient-to-br from-emerald-600 to-teal-700 text-white rounded-2xl p-6 shadow-lg relative overflow-hidden">
          <div className="absolute right-0 bottom-0 opacity-10 p-4">
            <Wallet className="w-32 h-32" />
          </div>
          <span className="text-xs font-bold text-emerald-100 uppercase tracking-wider block">الرصيد المتاح للسحب المباشر (Available Balance):</span>
          <p className="text-3xl font-black mt-2">{wallet.availableBalance.toLocaleString()} <span className="text-base font-bold">ج.م</span></p>
          <p className="text-xs text-emerald-100 mt-2 flex items-center gap-1">
            <ShieldCheck className="w-4 h-4" /> جاهز للتحويل الفوري لمقرك أو حسابك
          </p>
        </div>

        {/* Pending COD Box */}
        <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-2xs">
          <span className="text-xs font-bold text-slate-500 block">مبالغ قيد التحصيل مع المندوبين (Pending COD):</span>
          <p className="text-3xl font-black text-amber-600 mt-2">{wallet.pendingCod.toLocaleString()} <span className="text-base font-bold">ج.م</span></p>
          <p className="text-xs text-slate-500 mt-2">تتحول للرصيد المتاح فور تسليم الشحنة للعميل</p>
        </div>

        {/* Total Paid Out Box */}
        <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-2xs">
          <span className="text-xs font-bold text-slate-500 block">إجمالي التحويلات السابقة (Total Paid Out):</span>
          <p className="text-3xl font-black text-slate-900 mt-2">{wallet.totalPaidOut.toLocaleString()} <span className="text-base font-bold">ج.م</span></p>
          <p className="text-xs text-emerald-600 font-bold mt-2">تسويات مالية ناجحة 100%</p>
        </div>
      </div>

      {/* Instant Payout Form */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-2xs space-y-4">
        <h3 className="font-extrabold text-base text-slate-900 flex items-center gap-2 border-b border-slate-100 pb-3">
          <ArrowDownLeft className="w-5 h-5 text-emerald-600" />
          طلب سحب وتسوية مالية فورية (Request COD Payout)
        </h3>

        {payoutSuccessMsg && (
          <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 p-3 rounded-xl text-xs font-bold flex items-center gap-2">
            <CheckCircle className="w-4 h-4 text-emerald-600" />
            {payoutSuccessMsg}
          </div>
        )}

        <form onSubmit={handlePayoutSubmit} className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">المبلغ المراد سحبه (ج.م):</label>
            <input
              type="number"
              max={wallet.availableBalance}
              value={payoutAmount}
              onChange={(e) => setPayoutAmount(parseFloat(e.target.value) || 0)}
              className="w-full text-sm font-extrabold p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">طريقة التحويل المفضلة:</label>
            <select
              value={payoutMethod}
              onChange={(e) => setPayoutMethod(e.target.value as any)}
              className="w-full text-xs font-bold p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white"
            >
              <option value="instapay">InstaPay ({wallet.instaPayHandle})</option>
              <option value="vodafone">Vodafone Cash ({wallet.vodafoneCashNumber})</option>
              <option value="bank">حساب بنكي ({wallet.bankAccount?.bankName})</option>
            </select>
          </div>

          <button
            type="submit"
            className="bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs px-6 py-3 rounded-xl shadow-md transition-all flex items-center justify-center gap-2"
          >
            <ArrowDownLeft className="w-4 h-4" />
            تأكيد طلب التحويل الفوري
          </button>
        </form>
      </div>

      {/* Delivered COD Ledger Table */}
      <div className="bg-white border border-slate-200 rounded-2xl shadow-2xs overflow-hidden">
        <div className="p-4 border-b border-slate-200 font-extrabold text-sm text-slate-900 flex items-center justify-between">
          <span>سجل تحويلات الشحنات المسلمة (Delivered COD Ledger):</span>
          <span className="text-xs font-bold text-slate-500">{deliveredShipments.length} شحنة مكتملة</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-right text-xs">
            <thead className="bg-slate-50 text-slate-600 font-extrabold uppercase border-b border-slate-200">
              <tr>
                <th className="p-3">رقم البوليصة</th>
                <th className="p-3">المستلم</th>
                <th className="p-3">مبلغ التحصيل (COD)</th>
                <th className="p-3">رسوم الشحن والتحصيل</th>
                <th className="p-3">الصافي للتاجر</th>
                <th className="p-3">حالة التسوية</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {deliveredShipments.map((s) => (
                <tr key={s.id} className="hover:bg-slate-50/80">
                  <td className="p-3 font-mono font-black text-slate-900">{s.trackingNumber}</td>
                  <td className="p-3 font-bold text-slate-800">{s.recipient.name}</td>
                  <td className="p-3 font-extrabold text-slate-900">{s.financials.codAmount.toLocaleString()} ج.م</td>
                  <td className="p-3 text-red-600 font-bold">
                    -{s.financials.shippingFee + s.financials.codFee} ج.م
                  </td>
                  <td className="p-3 font-black text-emerald-600">{s.financials.netPayout.toLocaleString()} ج.م</td>
                  <td className="p-3">
                    <span className="bg-emerald-100 text-emerald-800 text-[10px] font-extrabold px-2.5 py-1 rounded-full border border-emerald-200">
                      جاهز للسحب
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
